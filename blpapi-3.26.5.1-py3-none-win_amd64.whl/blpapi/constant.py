# constant.py

"""Provide a representation for schema-level enumeration constants.

This file defines these classes:
    'Constant' - schema enumeration constant
    'ConstantList' - list of schema enumeration constants

This component provides a representation of a schema enumeration constant, and
a representation for lists of such constants
"""

from typing import Any, Iterator as IteratorType, Optional
from .exception import (
    _ExceptionUtil,
    NotFoundException,
    IndexOutOfRangeException,
)
from .name import Name, getNamePair
from .datatype import DataType
from .datetime import _DatetimeUtil
from . import typehints  # pylint: disable=unused-import
from .typehints import (
    AnyPythonDatetime,
    BlpapiConstantHandle,
    BlpapiConstantListHandle,
)
from . import utils
from . import internals
from .chandle import CHandle
from .ctypesutils import getRawPtrFromHandle

# pylint: disable=protected-access


class Constant(CHandle[internals.blpapi_Constant_t_p]):
    r"""Represents the value of a schema enumeration constant.

    Constants can be any of the following :class:`DataType`\s:
    :attr:`~DataType.BOOL`, :attr:`~DataType.CHAR`, :attr:`~DataType.BYTE`,
    :attr:`~DataType.INT32`, :attr:`~DataType.INT64`,
    :attr:`~DataType.FLOAT32`, :attr:`~DataType.FLOAT64`,
    :attr:`~DataType.STRING`, :attr:`~DataType.DATE`, :attr:`~DataType.TIME`,
    :attr:`~DataType.DATETIME`. This class provides access not only to to the
    constant value, but also to the symbolic name, the description, and the
    status of the constant.

    :class:`Constant` objects are read-only.

    Application clients never create :class:`Constant` object directly;
    applications will typically work with :class:`Constant` objects returned
    by other ``blpapi`` components.
    """

    def __init__(
        self,
        handle: BlpapiConstantHandle,
        parentSession: Optional[CHandle] = None,
    ) -> None:
        """
        Args:
            handle: Handle to the internal implementation
            parentSession: Parent session to which this object is related
        """
        super(Constant, self).__init__(handle, None, parentSession)

    def name(self) -> Name:
        """
        Returns:
            The symbolic name of this :class:`Constant`.
        """
        return Name._createInternally(
            internals.blpapi_Constant_name(self._handle())
        )

    def description(self) -> str:
        """
        Returns:
            Human readable description of this :class:`Constant`.
        """
        return internals.blpapi_Constant_description(self._handle())

    def status(self) -> int:
        """
        Returns:
            Status of this :class:`Constant`.

        The possible return values are enumerated in :class:`SchemaStatus`.
        """
        return internals.blpapi_Constant_status(self._handle())

    def datatype(self) -> int:
        """
        Returns:
            Data type used to represent the value of this :class:`Constant`.

        The possible return values are enumerated in :class:`DataType`.
        """
        return internals.blpapi_Constant_datatype(self._handle())

    def getValueAsInteger(self) -> int:
        """
        Returns:
            Value of this object as an integer.

        Raises:
            InvalidConversionException: If the value cannot be converted to an
                integer.
        """
        if self.datatype() == DataType.INT32:
            errCode, value = internals.blpapi_Constant_getValueAsInt32(
                self._handle()
            )
        else:
            errCode, value = internals.blpapi_Constant_getValueAsInt64(
                self._handle()
            )
        _ExceptionUtil.raiseOnError(errCode)
        return value

    def getValueAsFloat(self) -> float:
        """
        Returns:
            Value of this object as a float.

        Raises:
            InvalidConversionException: If the value cannot be converted to a
                float.
        """
        if self.datatype() == DataType.FLOAT32:
            errCode, value = internals.blpapi_Constant_getValueAsFloat32(
                self._handle()
            )
        else:
            errCode, value = internals.blpapi_Constant_getValueAsFloat64(
                self._handle()
            )
        _ExceptionUtil.raiseOnError(errCode)
        return value

    def getValueAsDatetime(self) -> AnyPythonDatetime:
        """
        Returns:
            Value of this object as one of the datetime types.

        Raises:
            InvalidConversionException: If the value cannot be converted to
                one of the datetime types.
        """
        errCode, value = internals.blpapi_Constant_getValueAsDatetime(
            self._handle()
        )
        _ExceptionUtil.raiseOnError(errCode)
        return _DatetimeUtil.convertToNativeNotHighPrecision(value)

    def getValueAsString(self) -> str:
        """
        Returns:
            Value of this object as a string.

        Raises:
            InvalidConversionException: If the value cannot be converted to a
                string.
        """
        if self.datatype() == DataType.CHAR:
            errCode, value = internals.blpapi_Constant_getValueAsChar(
                self._handle()
            )
        else:
            errCode, value = internals.blpapi_Constant_getValueAsString(
                self._handle()
            )
        _ExceptionUtil.raiseOnError(errCode)
        return value

    def getValue(self) -> Any:
        """
        Returns:
            Value of this object as it is stored in the object.
        """
        datatype = self.datatype()
        valueGetter = _CONSTANT_VALUE_GETTER.get(
            datatype, Constant.getValueAsString
        )
        return valueGetter(self)


class ConstantList(CHandle[internals.blpapi_ConstantList_t_p]):
    """Represents a list of schema enumeration constants.

    As well as the list of :class:`Constant` objects, this class also provides
    access to the symbolic name, description and status of the list as a whole.
    All :class:`Constant` objects in a :class:`ConstantList` are of the same
    :class:`DataType`.

    :class:`ConstantList` objects are read-only.

    Application clients never create :class:`ConstantList` object directly;
    applications will typically work with :class:`ConstantList` objects
    returned by other ``blpapi`` components.
    """

    def __init__(
        self,
        handle: BlpapiConstantListHandle,
        parentSession: Optional[CHandle] = None,
    ) -> None:
        """
        Args:
            handle: Handle to the internal implementation
            parentSession: Parent session to which this object is related
        """
        super(ConstantList, self).__init__(handle, None, parentSession)

    def __iter__(self) -> IteratorType:
        """
        Returns:
            Iterator over constants contained in this :class:`ConstantList`
        """
        return utils.Iterator(
            self, ConstantList.numConstants, ConstantList.getConstantAt
        )

    def name(self) -> Name:
        """
        Returns:
            Name: Symbolic name of this :class:`ConstantList`
        """
        return Name._createInternally(
            internals.blpapi_ConstantList_name(self._handle())
        )

    def description(self) -> str:
        """
        Returns:
            str: Human readable description of this :class:`ConstantList`
        """
        return internals.blpapi_ConstantList_description(self._handle())

    def status(self) -> int:
        """
        Returns:
            int: Status of this :class:`ConstantList`

        The possible return values are enumerated in :class:`SchemaStatus`
        """
        return internals.blpapi_ConstantList_status(self._handle())

    def numConstants(self) -> int:
        """
        Returns:
            int: Number of :class:`Constant` objects in this list
        """
        return internals.blpapi_ConstantList_numConstants(self._handle())

    def datatype(self) -> int:
        """
        Returns:
            int: Data type used to represent the value of this constant

        The possible return values are enumerated in :class:`DataType`.
        """
        return internals.blpapi_ConstantList_datatype(self._handle())

    def hasConstant(self, name: Name) -> bool:
        """
        Args:
            name: Name of the constant

        Returns:
            ``True`` if this :class:`ConstantList` contains an item with
            this ``name``.

        Raises:
            TypeError: If ``name`` is neither a :class:`Name` nor a string
        """
        names = getNamePair(name)
        return bool(
            internals.blpapi_ConstantList_hasConstant(
                self._handle(), names[0], names[1]
            )
        )

    def getConstant(self, name: Name) -> Constant:
        """
        Args:
            name: Name of the constant

        Returns:
            Constant with the specified ``name``

        Raises:
            NotFoundException: If this :class:`ConstantList` does not contain a
                :class:`Constant` with the specified ``name``
        """
        names = getNamePair(name)
        res = internals.blpapi_ConstantList_getConstant(
            self._handle(), names[0], names[1]
        )
        if res is None or getRawPtrFromHandle(res) is None:
            errMessage = (
                f"Constant '{name!s}' is not found in '{self.name()!s}'."
            )
            raise NotFoundException(errMessage, 0)
        return Constant(res, self._parent())

    def getConstantAt(self, position: int) -> Constant:
        """
        Args:
            position: Position of the requested constant in the list

        Returns:
            Constant at the specified ``position``.

        Raises:
            IndexOutOfRangeException: If ``position`` is not in the range from
                ``0`` to ``numConstants() - 1``.
        """
        res = internals.blpapi_ConstantList_getConstantAt(
            self._handle(), position
        )
        if res is None or getRawPtrFromHandle(res) is None:
            errMessage = f"Index '{position}' out of bounds."
            raise IndexOutOfRangeException(errMessage, 0)
        return Constant(res, self._parent())


_CONSTANT_VALUE_GETTER = {
    DataType.CHAR: Constant.getValueAsString,
    DataType.BYTE: Constant.getValueAsInteger,
    DataType.INT32: Constant.getValueAsInteger,
    DataType.INT64: Constant.getValueAsInteger,
    DataType.FLOAT32: Constant.getValueAsFloat,
    DataType.FLOAT64: Constant.getValueAsFloat,
    DataType.STRING: Constant.getValueAsString,
    DataType.DATE: Constant.getValueAsDatetime,
    DataType.TIME: Constant.getValueAsDatetime,
    DataType.DATETIME: Constant.getValueAsDatetime,
}

__copyright__ = """
Copyright 2012. Bloomberg Finance L.P.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to
deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:  The above
copyright notice and this permission notice shall be included in all copies
or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
IN THE SOFTWARE.
"""
