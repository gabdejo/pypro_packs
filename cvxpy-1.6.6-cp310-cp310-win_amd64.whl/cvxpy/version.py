
# THIS FILE IS GENERATED FROM CVXPY SETUP.PY
short_version = '1.6.6'
version = '1.6.6'
full_version = '1.6.6'
git_revision = 'dff0243'
commit_count = '0'
release = True
if not release:
    version = full_version
